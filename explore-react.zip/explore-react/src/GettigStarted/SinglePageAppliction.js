import React from "react";
import { Modal, Button } from 'react-bootstrap';

function SinglePageApplication() {
    const [isShow, invokeModal] = React.useState(false);
    const initModal = () => {
        return invokeModal(!isShow)
    }
    return (
        <div>
            <Button variant="success" onClick={initModal}>
                Open Modal
            </Button>
            <Modal show={isShow}>

                <Modal.Title>React Popup</Modal.Title>

                <Modal.Body>
                    Get started the expoler react js
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={initModal}>
                        Close
                    </Button>

                </Modal.Footer>
            </Modal>
        </div>

    );
}
export default SinglePageApplication;