import React, { useState } from 'react';

const initialList = [
    'Gettig Started',
    'JavaScript Refresher',
    'React Basics & Working With Components',
    'React State & Working With Events'
];

const AssigmentList = () => {
    const [value, setValue] = useState('');
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [list, setList] = useState(initialList);

    const handleChange = event => {
        setValue(event.target.value);
    };
    const handleSubmit = event => {
        if (value) {
            setList(list.concat(value));
        }
        setValue('');
        event.preventDefault();
    };
    function handleLogin() {
        setIsLoggedIn(true);
    }

    function handleLogout() {
        setIsLoggedIn(false);
    }

    return (
        <div>
            {isLoggedIn ? (
                <div>


                    <ul>
                        {list.map(item => (
                            <li key={item}>{item}</li>
                        ))}
                    </ul>

                    <form onSubmit={handleSubmit}>
                        <input type="text" value={value} onChange={handleChange} />
                        <button type="submit">Add Item</button>
                    </form>
                </div>
            ) : (<p>Not logged in!</p>)
            }
            <div>
                {isLoggedIn ? (
                    <button onClick={handleLogout}>Logout</button>
                ) : (
                    <button onClick={handleLogin}>Login</button>
                )}
            </div>

        </div>
    );
};

export default AssigmentList;