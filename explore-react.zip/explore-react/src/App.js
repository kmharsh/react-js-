import React from "react";

import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './style.css';
import SinglePageAppliction from "./GettigStarted/SinglePageAppliction";
import SpreadRestOperator from "./JavaScript-Refresher/Spread&Rest-Operator";
import Destructuring from "./JavaScript-Refresher/Destructuring";
import Arraymethods from "./JavaScript-Refresher/Arraymethods";
import PropsValue from "./React-Working-Components/Propsvalue";
import LogicalComponent from "./React-Working-Components/logical-component";
import Children from "./React-Working-Components/Children";
import Handler from "./React-StateWorking-With-Events/Handler";
import AssigmentList from "./Assignment/Assigment-List";
export default function App() {
    const propsdata = [
        {
            id: 'e2',
            title: 'total paper',
            amount: 250,
            date: new Date(2023, 5, 20),
        },
        {
            id: 'e1',
            title: 'total paper',
            amount: 200,
            date: new Date(2023, 4, 20),
        }
    ]


    return (
        <div className="container mx-auto">
            <div className="d-flex align-content-start flex-wrap">
                <div className="customcard-with">
                    <h5>React from Scratch</h5>
                    <SinglePageAppliction />
                </div>
                <div className="customcard-with">
                    <h5>Spread Rest Operator</h5>
                    <SpreadRestOperator />
                </div>
                <div className="customcard-with">
                    <h5>Destructuring</h5>
                    <Destructuring />
                </div>
                <div className="customcard-with">
                    <h5>Arraymethods</h5>
                    <Arraymethods />
                </div>
                <div className="customcard-with">
                    <h5>Props value passing</h5>
                    <PropsValue propsdata={propsdata} />
                </div>
                <div className="customcard-with">
                    <h5>LogicalComponent</h5>
                    <LogicalComponent>
                        <Children />
                    </LogicalComponent>
                </div>
                <div className="customcard-with">
                    <h5>Event handler </h5>
                        <Handler/>
                </div>
                <div className="customcard-with">
                    <h5>Assigment List </h5>
                        <AssigmentList/>
                </div>

            </div>

        </div>
    );
}