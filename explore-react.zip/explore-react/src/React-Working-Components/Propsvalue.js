import React from "react";
export default function Propsvalue(props) {

    const data = props.propsdata;
    return (
        <div className="">
            {data.map((p, index) => (
                <div key={index} className="card customcard-with">
                    <p>ID: {p.id}</p>
                    <p>Title: {p.title}</p>
                    <p> Amount: {p.amount}</p>
                    <p>Date:{p.date.toDateString()}</p>
                </div>
            ))}
        </div>
    );
}