import React, { useEffect, useState } from "react";
export default function logicalcomponent({ children }) {

    const [show, setShow] = useState();
    function toggleShow() {
        setShow(!show);
    }
    var buttonText = show ? "Hide Component" : "Show Component";
    return (
        <div>
            <div className="component-container">
                {show && children}
                <button onClick={toggleShow}>{buttonText}</button>
            </div>
        </div>
    );

}
