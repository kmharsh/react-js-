import React from "react";
export default function Default() {
  return (
    <div className="default-container">
      <p>Welcome to React</p>
      <span>Click below to toggle visiblity</span>
    </div>
  );
}