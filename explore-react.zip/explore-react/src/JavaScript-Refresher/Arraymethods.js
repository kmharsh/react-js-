import React from "react";
export default function Arraymethods() {
    const employees = [
        {
            name: 'Saka Manje',
            address: '14, cassava-garri-ewa street',
            gender: 'Male',
        },
        {
            name: 'Wawawa Warisii',
            address: '406, highway street',
            gender: 'Male',
        },
    ]
    return (
        <div >
          {employees.map((employee, index) => (
            <div key={index} className="card customcard-with">
                <p>Name: {employee.name}</p>
                <p>Address: {employee.address}</p>
                <p>Gender: {employee.gender}</p>
            </div>
          ))}
        </div>
      );
}