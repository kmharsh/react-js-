import React from "react";
export default function SpreadRestOperator() {
    const fillter = (...age) => {
        return age.filter(el => el === 2);
    }

    return (
        <div>
            Spreadvalue={fillter(1, 2, 3, 4)}
        </div>
    );
}