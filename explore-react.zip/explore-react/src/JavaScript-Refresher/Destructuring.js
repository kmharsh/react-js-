import React from "react";
export default function Destructuring() {
    const person = {
        firstName: "Nick",
        lastName: "Anderson",
        age: 35,
        sex: "M"
    }

    return (
        <div className="card customcard-with">
            <div class="card-body">
                <p>FirstName: {person.firstName}</p>
                <p>Age :{person.age}</p>
                <p>Gender: {person.sex}</p>
                <p>City : {person.city || "Paris"}</p>
            </div>

        </div>
    );
}